package com.example.mobi.models;

public class User {
    private String user_id;
    private String fname;
    private String lname;
    private String email;
    private String pword;
    private int balance;
}
